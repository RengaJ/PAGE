#include "page_mesh.h"

using namespace PAGE;

Vertex::Vertex()
{
    position = Vector4();
    normal = Vector3();
    color = Vector3(1,1,1);
    uv = Vector2();
}
Vertex::Vertex( Vector4 pos )
{
    position = pos;
    normal = Vector3();
    color = Vector3(1,1,1);
    uv = Vector2();
}
Vertex::Vertex( Vector4 pos, Vector3 norm )
{
    position = pos;
    normal = norm;
    color = Vector3(1,1,1);
    uv = Vector2();
}
Vertex::Vertex( Vector4 pos, Vector3 norm, Vector3 color )
{
    position = pos;
    normal = norm;
    this->color = color;
    uv = Vector2();
}
Vertex::Vertex( Vector4 pos,Vector3 norm,
                Vector3 color, Vector2 uvs )
{
    position = pos;
    normal = norm;
    this->color = color;
    uv = uvs;
}

Vertex& Vertex::operator=(const Vertex& vert)
{
    if (this == &vert)
        return *this;
    position = vert.position;
    normal = vert.normal;
    uv = vert.uv;

    return *this;
}


Mesh::Mesh()
{
    vertices = std::vector<Vertex>();
    triangles = std::vector<int>();
    coordinateSystem = Y_UP;
}

void Mesh::add_triangle(Vector3 &triangle)
{
    triangles.push_back((int)triangle.x);
    triangles.push_back((int)triangle.y);
    triangles.push_back((int)triangle.z);
}

void Mesh::add_triangle(int v1, int v2, int v3)
{
    triangles.push_back(v1);
    triangles.push_back(v2);
    triangles.push_back(v3);
}

void Mesh::convert_verts(Vertex_S vert[])
{
    int size = vert_array_size();
    for (int i = 0; i < vertices.size(); i++)
    {
        Vertex_S v;
        for (int j = 0; j < 4; j++)
        {
            v.position[j] = vertices[i].position[j];
            if ( j < 3 )
            {
                v.normal[j] = vertices[i].normal[j];
                v.color[j] = vertices[i].color[j];
                if ( j < 2 )
                    v.uv[j] = vertices[i].uv[j];
            }
        }
        vert[i] = v;
    }
}
