#ifndef __PAGE_PARSER_H
#define __PAGE_PARSER_H

namespace PAGE
{
	class Parser
	{
		public:
			static void parse_egg(const char* filename, Mesh* mesh);
			static void parse_egg_texture();
			static void parse_egg_vertex();
			static void parse_egg_triangle();
		private:
			Parser();
	}
}
#endif
