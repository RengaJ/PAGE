#ifndef __PAGE_MESH_H
#define __PAGE_MESH_H

#include "page_vector.h"
#include "page_debug.h"
#include <vector>

namespace PAGE
{
	class Vertex
	{
		public:
            Vertex();
            Vertex( Vector4 pos );
            Vertex( Vector4 pos, Vector3 norm );
            Vertex( Vector4 pos, Vector3 norm, Vector3 color );
			Vertex( Vector4 pos, Vector3 norm, Vector3 color, Vector2 uvs );
			Vertex(const Vertex &vert) { *this = vert; }

			Vertex& operator=(const Vertex &vert);
			Vector4 position;
			Vector3 normal;
			Vector3 color;
			Vector2 uv;
	};

	struct Vertex_S
	{
		float position[4];
		float normal[3];
		float color[3];
		float uv[2];
	};

	class Mesh
	{
		public:
			enum CoordinateSystem { Y_UP, Y_UP_RIGHT, Y_UP_LEFT, Z_UP, Z_UP_RIGHT, Z_UP_LEFT };
			Mesh();

			int vert_count () { return vertices.size(); }
			int tris_count () { return triangles.size(); }
			void add_vertex(Vertex &v) { vertices.push_back(Vertex(v.position,v.normal,v.color,v.uv)); }
			void add_triangle(Vector3 &triangle);
			void add_triangle(int v1, int v2, int v3);

			std::vector<Vertex> verts() { return vertices; }
			std::vector<int> tris() { return triangles; }

			int vert_array_size() { return vertices.size() * sizeof(Vertex)/sizeof(float); }

			void convert_verts(Vertex_S vert[]);

			CoordinateSystem get_coordinate_system() { return coordinateSystem; }
			void set_coordinate_system(CoordinateSystem system) { coordinateSystem = system; }

		private:
			CoordinateSystem coordinateSystem;
			std::vector<Vertex> vertices;
			std::vector<int> triangles;
	};
}

#endif
