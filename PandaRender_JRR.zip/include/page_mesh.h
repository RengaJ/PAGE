#ifndef __PAGE_MESH_H
#define __PAGE_MESH_H

#include "page_vector.h"
#include "page_debug.h"
#include <vector>

namespace PAGE
{
	class Vertex
	{
		public:
			Vertex() { position = Vector4();normal = Vector3(); uv = Vector2(); }
			Vertex( Vector4 pos ) { position = pos; normal = Vector3(); uv = Vector2(); }
			Vertex( Vector4 pos, Vector3 norm ) { position = pos; normal = norm; uv = Vector2(); }
			Vertex( Vector4 pos, Vector3 norm, Vector2 uvs ) { position = pos; normal = norm; uv = uvs; }
			Vertex(const Vertex &vert) { *this = vert; }

			Vertex& operator=(const Vertex &vert)
			{
				if (this == &vert)
					return *this;
				position = vert.position;
				normal = vert.normal;
				uv = vert.uv;

				return *this;
			}

			Vector4 position;
			Vector3 normal;
			Vector2 uv;
	};

	struct Vertex_S
	{
		float position[4];
		float normal[3];
		float uv[2];
	};

	class Mesh
	{
		public:
			enum CoordinateSystem { Y_UP, Y_UP_RIGHT, Y_UP_LEFT, Z_UP, Z_UP_RIGHT, Z_UP_LEFT };
			Mesh() { vertices = std::vector<Vertex>(); triangles = std::vector<int>(); coordinateSystem = Y_UP; };

			int vert_count () { return vertices.size(); }
			int tris_count () { return triangles.size(); }
			void add_vertex(Vertex &v) { vertices.push_back(Vertex(v.position,v.normal,v.uv)); }
			void add_triangle(Vector3 &triangle)
			{
				triangles.push_back((int)triangle.x);
				triangles.push_back((int)triangle.y);
				triangles.push_back((int)triangle.z);
			}
			void add_triangle(int v1, int v2, int v3)
			{
				triangles.push_back(v1);
				triangles.push_back(v2);
				triangles.push_back(v3);
			}

			std::vector<Vertex> verts() { return vertices; }
			std::vector<int> tris() { return triangles; }

			int vert_array_size() { return vertices.size() * sizeof(Vertex)/sizeof(float); }

			void convert_verts(Vertex_S* vert)
			{
				int size = vert_array_size();
				for (int i = 0; i < vertices.size(); i++)
				{
					Vertex_S v;
					for (int j = 0; j < 3; j++)
					{
						v.position[j] = vertices[i].position[j];
						v.normal[j] = vertices[i].normal[j];
						if ( j < 2 )
							v.uv[j] = vertices[i].uv[j];
					}
					vert[i] = v;
				}
			}

			CoordinateSystem get_coordinate_system() { return coordinateSystem; }
			void set_coordinate_system(CoordinateSystem system) { coordinateSystem = system; }

		private:
			CoordinateSystem coordinateSystem;
			std::vector<Vertex> vertices;
			std::vector<int> triangles;
	};
}

#endif
